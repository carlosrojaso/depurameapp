(function(){if(Meteor.isClient){
  // Local (client-only) collection
  Errors = new Meteor.Collection(null);
}

})();
