(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Notifications = Package['kestanous:herald'].Notifications;
var Herald = Package['kestanous:herald'].Herald;

(function () {

/////////////////////////////////////////////////////////////////////////////////////
//                                                                                 //
// packages/kestanous:herald-email/lib/notifications-email.js                      //
//                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////
                                                                                   //
Herald.addRunner('email', function (notification, user) {                          // 1
  this.emailRunner.call(notification, user)                                        // 2
});                                                                                // 3
                                                                                   // 4
// == TODO: emailSummery ==                                                        // 5
// Herald.addRunner('emailSummery', function (notification, user) { /* noop */ }); // 6
//                                                                                 // 7
// Fire email summery based on some timer/date-time.                               // 8
// Will get all applicable notifications from user and summarize them.             // 9
                                                                                   // 10
/////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['kestanous:herald-email'] = {};

})();
