(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Avatar;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['bengott:avatar'] = {
  Avatar: Avatar
};

})();
