(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package.livedata.DDP;
var DDPServer = Package.livedata.DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var Notifications, Herald, transform, users, userId, sendToMedium, checkUserPreferencesSet;

(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/kestanous:herald/lib/notifications.js                                                           //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
                                                                                                            // 1
//This is our Global Object.                                                                                // 2
Herald = {                                                                                                  // 3
  //Notification global settings                                                                            // 4
  settings: {                                                                                               // 5
    overrides: {}, //disable functionality for all users.                                                   // 6
    delayEscalation: false                                                                                  // 7
  },                                                                                                        // 8
                                                                                                            // 9
  _media: ['onsite'], //supported media, extension packages should push new kinds                           // 10
  _mediaRunners: {}, //extension packages load their code here                                              // 11
  _extentionParams: [], //UNDOCUMENTED: allow for more top level params on EventTypes                       // 12
                                                                                                            // 13
  //EventTypes allows us to add reusable logic that can be updated                                          // 14
  //without the need for migrations.                                                                        // 15
  //                                                                                                        // 16
  // messageFormat - a function that the package user defines, outputs a message string                     // 17
  // metadata - useful data like template names that don't need to be in the database                       // 18
  // media - where these notifications should be sent.                                                      // 19
  _courier: {},                                                                                             // 20
  //add an courier                                                                                          // 21
  addCourier: function (key, options) {                                                                     // 22
    check(key, String);                                                                                     // 23
    if (Herald._courier[key])                                                                               // 24
      throw new Error('Herald: courier type "' + key + '"" already exists');                                // 25
                                                                                                            // 26
    // Package users can define a predefined message from the notification instance.                        // 27
    // It requires the user pass a options.message function, string, or object.                             // 28
    //                                                                                                      // 29
    // If its a function it will be run with the from the instance scope                                    // 30
    //                                                                                                      // 31
    // If its a string it will return a template with the instance                                          // 32
    // as its data.                                                                                         // 33
    //                                                                                                      // 34
    // If its an object it will run any number of templates or functions based on the optional              // 35
    // string argument given at the time of call. If no string is passed it will default                    // 36
    // to 'default'. From there it acts the same as ether of the above patterns.                            // 37
    var message = function (template) {                                                                     // 38
      var message, messageFormat = Herald._courier[key].messageFormat                                       // 39
                                                                                                            // 40
      if (_.isObject(messageFormat) && !_.isFunction(messageFormat) && !_.isString(messageFormat)) {        // 41
        if (messageFormat[template]) {                                                                      // 42
          message = messageFormat[template]                                                                 // 43
        } else {                                                                                            // 44
          message = messageFormat.default                                                                   // 45
          if (!message) {                                                                                   // 46
            throw new Error('Herald: No default message defined for "' + this.courier + '" notifications'); // 47
          }                                                                                                 // 48
        }                                                                                                   // 49
      }                                                                                                     // 50
      message = message || messageFormat                                                                    // 51
                                                                                                            // 52
      if (_.isFunction(message)) {                                                                          // 53
        return message.apply(this)                                                                          // 54
      }                                                                                                     // 55
                                                                                                            // 56
      else if (_.isString(message)) {                                                                       // 57
        return Blaze.With(this, function(){                                                                 // 58
          return Template[message]                                                                          // 59
        });                                                                                                 // 60
      }                                                                                                     // 61
                                                                                                            // 62
      else {                                                                                                // 63
        throw new Error('Herald: message not defined for "' + this.courier + '" notifications');            // 64
      }                                                                                                     // 65
    }                                                                                                       // 66
                                                                                                            // 67
                                                                                                            // 68
    check(options, Object);                                                                                 // 69
    Herald._courier[key] = {                                                                                // 70
      message: message,                                                                                     // 71
      messageFormat: options.message                                                                        // 72
    };                                                                                                      // 73
                                                                                                            // 74
    //media is required but should only throw exceptions on the server, where it is needed.                 // 75
    if (Meteor.isServer) {                                                                                  // 76
      check(options.media, Object);                                                                         // 77
      var media = _.keys(options.media)                                                                     // 78
      if (media.length == 0)                                                                                // 79
        throw new Error('Herald: courier "'+ key + '" must have at least one medium');                      // 80
      media.forEach(function (medium) {                                                                     // 81
        if (!_.contains(Herald._media, medium))                                                             // 82
          throw new Error('Herald: medium "' + medium + '" is not a known media');                          // 83
      });                                                                                                   // 84
    }                                                                                                       // 85
    //define on both, just in case                                                                          // 86
    Herald._courier[key].media = options.media                                                              // 87
                                                                                                            // 88
    if (options.metadata) {                                                                                 // 89
      console.warn('Herald: metadata is depreciated, use transform');                                       // 90
      metadata: options.metadata;                                                                           // 91
    };                                                                                                      // 92
    Herald._courier[key].transform = options.transform;                                                     // 93
                                                                                                            // 94
    //white-listed params from extension packages                                                           // 95
    _.extend(Herald._courier[key], _.pick(options, Herald._extentionParams))                                // 96
  }                                                                                                         // 97
};                                                                                                          // 98
                                                                                                            // 99
//The collection and any instance functionality                                                             // 100
Herald.collection = new Meteor.Collection('notifications', {                                                // 101
  transform: function (notification) {                                                                      // 102
    if (notification.courier) { //courier may not be available if fields filter was called.                 // 103
                                                                                                            // 104
      //This is the basic message you want to output. Use in the app or as an email subject line            // 105
      // it is optional and is set up with createNotification from the server code.                         // 106
      notification.message = function (template) {                                                          // 107
        check(template, Match.Optional(String));                                                            // 108
        if (Herald._courier[this.courier].message) {                                                        // 109
          //make the notification data accessible to the message function.                                  // 110
          return Herald._courier[this.courier].message.call(this, template)                                 // 111
        };                                                                                                  // 112
      };                                                                                                    // 113
                                                                                                            // 114
      //deprecated in favor of transform                                                                    // 115
      //Load the current metadata, this will update with a hot-code-push.                                   // 116
      notification.metadata = Herald._courier[notification.courier].metadata                                // 117
                                                                                                            // 118
      //internal scoping and cloning, because js is magically confusing                                     // 119
      if (Herald._courier[notification.courier].transform) {                                                // 120
        transform = _.clone(Herald._courier[notification.courier].transform)                                // 121
        notification = _.extend(transform, notification)                                                    // 122
      }                                                                                                     // 123
    };                                                                                                      // 124
    return notification                                                                                     // 125
  }                                                                                                         // 126
});                                                                                                         // 127
                                                                                                            // 128
//Minimum requirement for notifications to work while still providing                                       // 129
//basic security. For added limitations use `Herald.deny` in                                                // 130
//your app.                                                                                                 // 131
Herald.collection.allow({                                                                                   // 132
  insert: function(userId, doc){                                                                            // 133
    // new notifications can only be created via a Meteor method                                            // 134
    return false;                                                                                           // 135
  },                                                                                                        // 136
  update: function (userId, doc) {                                                                          // 137
    return userId == doc.userId                                                                             // 138
  },                                                                                                        // 139
  remove: function (userId, doc) {                                                                          // 140
    return userId == doc.userId                                                                             // 141
  }                                                                                                         // 142
});                                                                                                         // 143
                                                                                                            // 144
                                                                                                            // 145
//literally mark-All-Herald-As-Read, cheers :)                                                              // 146
Meteor.methods({                                                                                            // 147
  markAllNotificationsAsRead: function() {                                                                  // 148
    Herald.collection.update(                                                                               // 149
      {userId: Meteor.userId()},                                                                            // 150
      {                                                                                                     // 151
        $set:{                                                                                              // 152
          read: true                                                                                        // 153
        }                                                                                                   // 154
      },                                                                                                    // 155
      {multi: true}                                                                                         // 156
    );                                                                                                      // 157
  }                                                                                                         // 158
});                                                                                                         // 159
                                                                                                            // 160
if (Package['mizzao:user-status']) {                                                                        // 161
  //TODO: somehow notifications should be user aware... somehow                                             // 162
}                                                                                                           // 163
                                                                                                            // 164
                                                                                                            // 165
                                                                                                            // 166
Notifications = Herald                                                                                      // 167
                                                                                                            // 168
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/kestanous:herald/lib/server.js                                                                  //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
// only publish notifications belonging to the current user                                                 // 1
Meteor.publish('notifications', function() {                                                                // 2
  return Herald.collection.find({userId:this.userId, onsite: true});                                        // 3
});                                                                                                         // 4
                                                                                                            // 5
//You can insert manually but this should save you some work.                                               // 6
Herald.createNotification = function (userIds, params) {                                                    // 7
                                                                                                            // 8
                                                                                                            // 9
  check(userIds, Match.OneOf([String], String)); //TODO: better Collection ID check                         // 10
  check(params, Object);                                                                                    // 11
  if (!Herald._courier[params.courier])                                                                     // 12
    throw new Error('Notification: courier type does not exists');                                          // 13
                                                                                                            // 14
  // always assume multiple users.                                                                          // 15
  if (_.isString(userIds)) userIds = [userIds]                                                              // 16
  users = Meteor.users.find({_id: {$in: userIds}}, {fields: {profile: 1}})                                  // 17
  users.forEach(function (user) {                                                                           // 18
    //create a notification for each user                                                                   // 19
    userId = user._id                                                                                       // 20
                                                                                                            // 21
    //When creating a new notification                                                                      // 22
    //                                                                                                      // 23
    // timestamp - you should timestamp every doc                                                           // 24
    // userId - there must be a user to notify                                                              // 25
    // courier - this is the courier                                                                        // 26
    // data - in database metadata, consider renaming                                                       // 27
    // read - default false, consider auto-delete?                                                          // 28
    // escalated - track if higher level notifications have run                                             // 29
    // url - allow of iron:router magic. set read to true if visited (see routeSeenByUser)                  // 30
                                                                                                            // 31
    var notification = {                                                                                    // 32
      timestamp: new Date().getTime(),                                                                      // 33
      userId: userId,                                                                                       // 34
      courier: params.courier,                                                                              // 35
      data: params.data,                                                                                    // 36
      read: false,                                                                                          // 37
      escalated: false,                                                                                     // 38
      url: params.url                                                                                       // 39
    };                                                                                                      // 40
                                                                                                            // 41
    _.each(_.keys(Herald._courier[params.courier].media), function (medium) {                               // 42
      //check if this notification should be sent to medium                                                 // 43
      if (sendToMedium(user, params.courier, medium)) {                                                     // 44
        notification[medium] = true                                                                         // 45
      };                                                                                                    // 46
    });                                                                                                     // 47
                                                                                                            // 48
    //create notification and return its id                                                                 // 49
    var notificationId = Herald.collection.insert(notification);                                            // 50
                                                                                                            // 51
    //if no pattern to delay escalation has been defined run escalation now                                 // 52
    //if no notificationId then insert failed anD PANIC, STOP, DON'T ACUTALLY DO THIS!                      // 53
    if (!Herald.settings.delayEscalation && notificationId) {                                               // 54
      notification._id = notificationId                                                                     // 55
      Herald.escalate(notification, user)                                                                   // 56
    }                                                                                                       // 57
                                                                                                            // 58
    return notificationId;                                                                                  // 59
  });                                                                                                       // 60
};                                                                                                          // 61
                                                                                                            // 62
sendToMedium = function (user, courier, medium) {                                                           // 63
  var mediumObject = Herald._courier[courier].media[medium]                                                 // 64
                                                                                                            // 65
  //does this courier support this medium? (false positive)                                                 // 66
  if (!mediumObject) {                                                                                      // 67
    return false;                                                                                           // 68
  };                                                                                                        // 69
  //is this medium blocked by admin?                                                                        // 70
  if (Herald.settings.overrides[medium]) {                                                                  // 71
    return false;                                                                                           // 72
  };                                                                                                        // 73
  //does the user want notifications on this medium?                                                        // 74
  //check general preferences and courier preferences                                                       // 75
  if (checkUserPreferencesSet(user, courier, medium)) { //has any preferences                               // 76
    if (user.profile.notificationPreferences[medium]) { //has general preferences                           // 77
      if (user.profile.notificationPreferences[courier]) { //override general preference                    // 78
        if (user.profile.notificationPreferences[courier][medium]) {                                        // 79
          return true;                                                                                      // 80
        };                                                                                                  // 81
      } else {                                                                                              // 82
        return true;                                                                                        // 83
      };                                                                                                    // 84
    } else if (user.profile.notificationPreferences.courier //courier only preference                       // 85
      && user.profile.notificationPreferences.courier[medium]) {                                            // 86
      return true;                                                                                          // 87
    };                                                                                                      // 88
  };                                                                                                        // 89
  //if no user preference then use courier default                                                          // 90
  if (mediumObject.hasOwnProperty('default')) {                                                             // 91
    if (mediumObject.default) {                                                                             // 92
      return true;                                                                                          // 93
    };                                                                                                      // 94
  } else {                                                                                                  // 95
    return true;                                                                                            // 96
  };                                                                                                        // 97
  return false;                                                                                             // 98
};                                                                                                          // 99
                                                                                                            // 100
//existence check                                                                                           // 101
checkUserPreferencesSet = function (user, courier, medium) {                                                // 102
  return (user.profile && user.profile.notificationPreferences &&                                           // 103
    (user.profile.notificationPreferences[courier] || user.profile.notificationPreferences[medium]));       // 104
};                                                                                                          // 105
                                                                                                            // 106
                                                                                                            // 107
//allow package users to delay escalations                                                                  // 108
Meteor.startup(function () {                                                                                // 109
  //if no pattern is defined then skip this.                                                                // 110
  if (!Herald.settings.delayEscalation) return false;                                                       // 111
});                                                                                                         // 112
                                                                                                            // 113
Herald.escalate = function (notification, user) {                                                           // 114
  if (notification.escalated) return false; //don't resend notifications                                    // 115
  user = user || Meteor.users.findOne(notification.userId);                                                 // 116
  _.each(_.keys(Herald._courier[notification.courier].media), function (medium) {                           // 117
    if (medium == 'onsite') return;                                                                         // 118
    if (sendToMedium(user, notification.courier, medium)) {                                                 // 119
      Herald._mediaRunners[medium].call(                                                                    // 120
        Herald._courier[notification.courier].media[medium], notification, user)                            // 121
    };                                                                                                      // 122
  });                                                                                                       // 123
  Herald.collection.update(notification._id, { $set: { escalated: true } } );                               // 124
};                                                                                                          // 125
                                                                                                            // 126
Herald.addRunner = function (name, fn) {                                                                    // 127
  Herald._media.push(name)                                                                                  // 128
  Herald._mediaRunners[name] = fn                                                                           // 129
}                                                                                                           // 130
                                                                                                            // 131
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['kestanous:herald'] = {
  Notifications: Notifications,
  Herald: Herald
};

})();
