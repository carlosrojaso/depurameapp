(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var AccountsTemplates = Package['splendido:accounts-templates-core'].AccountsTemplates;
var Accounts = Package['accounts-base'].Accounts;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var RouteController = Package['iron:router'].RouteController;
var Route = Package['iron:router'].Route;
var Router = Package['iron:router'].Router;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['splendido:accounts-templates-unstyled'] = {};

})();
